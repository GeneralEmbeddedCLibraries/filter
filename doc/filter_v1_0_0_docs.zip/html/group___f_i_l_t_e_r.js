var group___f_i_l_t_e_r =
[
    [ "filter_rc_s", "structfilter__rc__s.html", [
      [ "alpha", "structfilter__rc__s.html#ad521290165f6e9312fcb6cb3b261ec6a", null ],
      [ "order", "structfilter__rc__s.html#a724eaefaabd8537c02515cf045ad15d8", null ],
      [ "p_y", "structfilter__rc__s.html#aea1927b522b510af4163fe2be12fc2d3", null ]
    ] ],
    [ "filter_cr_s", "structfilter__cr__s.html", [
      [ "alpha", "structfilter__cr__s.html#aa7733e3c4d6b7df1ca9d3426007a18fe", null ],
      [ "order", "structfilter__cr__s.html#a525c87e6c0c1f39205162a311ffbd7ba", null ],
      [ "p_x", "structfilter__cr__s.html#a4c47659c82341f6652387c035bc5904d", null ],
      [ "p_y", "structfilter__cr__s.html#a48cb1bc8f6e85f56beb1706444a887a3", null ]
    ] ],
    [ "filter_fir_s", "structfilter__fir__s.html", [
      [ "order", "structfilter__fir__s.html#a6010923a5c399383767c1519f11e9a3d", null ],
      [ "p_a", "structfilter__fir__s.html#a00c582ca71ae648b0b4951e82ba288ee", null ],
      [ "p_x", "structfilter__fir__s.html#ac1bf58c49921070ca8107bfaf107cca1", null ]
    ] ],
    [ "filter_iir_s", "structfilter__iir__s.html", [
      [ "p_pole", "structfilter__iir__s.html#aa3e1c28f5d339e4a296777b673ac163a", null ],
      [ "p_x", "structfilter__iir__s.html#abd2a644041259b358920a853d7376e1c", null ],
      [ "p_y", "structfilter__iir__s.html#a47879d9748d530fc436d3f9a5d37b925", null ],
      [ "p_zero", "structfilter__iir__s.html#adedb4c2ea33f6b0f93e86dc3d8308145", null ],
      [ "pole_size", "structfilter__iir__s.html#a7586f1fd8d4e33afa470167400ea1169", null ],
      [ "zero_size", "structfilter__iir__s.html#a62e5320b9b271932be1081fb2d1821af", null ]
    ] ],
    [ "filter_cr_t", "group___f_i_l_t_e_r.html#gaa80d66649b25f874b1f10816353873f3", null ],
    [ "filter_fir_t", "group___f_i_l_t_e_r.html#gabf340b4bc58dd91ab2ad955791b3c34f", null ],
    [ "filter_iir_t", "group___f_i_l_t_e_r.html#gad3952f4d72906ad215f5c3d2744703e9", null ],
    [ "filter_rc_t", "group___f_i_l_t_e_r.html#gab1df74685beea7eefab2d3045b5f6368", null ],
    [ "filter_cr_calculate_alpha", "group___f_i_l_t_e_r.html#gac0baa7daa0c32ef7077285cab67e5149", null ],
    [ "filter_cr_change_cutoff", "group___f_i_l_t_e_r.html#gae097327cb57d73b837896378df4da9e3", null ],
    [ "filter_cr_init", "group___f_i_l_t_e_r.html#gacbbb56236e4a5c7da76e204b7fc1b5a9", null ],
    [ "filter_cr_update", "group___f_i_l_t_e_r.html#ga3663a71f2af4019d233e1e6045473ea9", null ],
    [ "filter_fir_init", "group___f_i_l_t_e_r.html#ga92ff12087aed0b6b5a2a239de278923c", null ],
    [ "filter_fir_update", "group___f_i_l_t_e_r.html#gab4763747aad28ff0046b3670c00ed1da", null ],
    [ "filter_iir_calc_coeff_2nd_hpf", "group___f_i_l_t_e_r.html#ga818373670bdcfa60335e2c0ff44629dc", null ],
    [ "filter_iir_calc_coeff_2nd_lpf", "group___f_i_l_t_e_r.html#gaf32e4ee86d4b61fe56354e3c96706abf", null ],
    [ "filter_iir_calc_coeff_2nd_notch", "group___f_i_l_t_e_r.html#gada20b609638d480b0ab6e77ccbf7b001", null ],
    [ "filter_iir_calc_dc_gain", "group___f_i_l_t_e_r.html#ga8bc6c83615193d6c89e4bcbb82bda768", null ],
    [ "filter_iir_change_coeff", "group___f_i_l_t_e_r.html#gabff8cab84317b1b6ae744c6a17182e3d", null ],
    [ "filter_iir_init", "group___f_i_l_t_e_r.html#ga99c51ff1156dc1031f3769ad50638cf4", null ],
    [ "filter_iir_norm_to_unity_gain", "group___f_i_l_t_e_r.html#ga9b09ade3da48c4663e97daf0fc853002", null ],
    [ "filter_iir_update", "group___f_i_l_t_e_r.html#gaa13faa4b920444b83d4fa10bfd93b075", null ],
    [ "filter_rc_calculate_alpha", "group___f_i_l_t_e_r.html#gac0c0fc9e1d72c0bb263631ed5420dbdd", null ],
    [ "filter_rc_change_cutoff", "group___f_i_l_t_e_r.html#gad7b421c1d3790d3fb4abc9942e9ec220", null ],
    [ "filter_rc_init", "group___f_i_l_t_e_r.html#ga7ebc96ade57af570a6860b2ccd41ee47", null ],
    [ "filter_rc_update", "group___f_i_l_t_e_r.html#ga93d2922ac93737a4e64f1f8f98768fa0", null ]
];