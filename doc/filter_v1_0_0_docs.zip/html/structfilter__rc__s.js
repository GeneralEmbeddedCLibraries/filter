var structfilter__rc__s =
[
    [ "alpha", "structfilter__rc__s.html#ad521290165f6e9312fcb6cb3b261ec6a", null ],
    [ "order", "structfilter__rc__s.html#a724eaefaabd8537c02515cf045ad15d8", null ],
    [ "p_y", "structfilter__rc__s.html#aea1927b522b510af4163fe2be12fc2d3", null ]
];