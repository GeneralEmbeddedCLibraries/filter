var searchData=
[
  ['alpha_70',['alpha',['../structfilter__rc__s.html#ad521290165f6e9312fcb6cb3b261ec6a',1,'filter_rc_s::alpha()'],['../structfilter__cr__s.html#aa7733e3c4d6b7df1ca9d3426007a18fe',1,'filter_cr_s::alpha()']]]
];
