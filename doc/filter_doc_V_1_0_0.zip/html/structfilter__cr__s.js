var structfilter__cr__s =
[
    [ "alpha", "structfilter__cr__s.html#aa7733e3c4d6b7df1ca9d3426007a18fe", null ],
    [ "fc", "structfilter__cr__s.html#affc5f78b414b5feeb2499ce6a264e4bc", null ],
    [ "is_init", "structfilter__cr__s.html#aef12a11faf36c5aa9d209b319c7064e8", null ],
    [ "order", "structfilter__cr__s.html#a525c87e6c0c1f39205162a311ffbd7ba", null ],
    [ "p_x", "structfilter__cr__s.html#a4c47659c82341f6652387c035bc5904d", null ],
    [ "p_y", "structfilter__cr__s.html#a48cb1bc8f6e85f56beb1706444a887a3", null ]
];