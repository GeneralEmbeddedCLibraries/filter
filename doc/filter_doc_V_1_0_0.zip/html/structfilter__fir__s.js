var structfilter__fir__s =
[
    [ "is_init", "structfilter__fir__s.html#a7433d153d0a1f98d3a15dcd78b92c6fb", null ],
    [ "order", "structfilter__fir__s.html#a6010923a5c399383767c1519f11e9a3d", null ],
    [ "p_a", "structfilter__fir__s.html#a00c582ca71ae648b0b4951e82ba288ee", null ],
    [ "p_x", "structfilter__fir__s.html#ac1bf58c49921070ca8107bfaf107cca1", null ]
];