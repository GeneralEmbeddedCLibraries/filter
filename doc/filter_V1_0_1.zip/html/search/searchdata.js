var indexSectionsWithContent =
{
  0: "aefiopz",
  1: "f",
  2: "f",
  3: "f",
  4: "afiopz",
  5: "fp",
  6: "f",
  7: "e",
  8: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules"
};

